import pandas as pd
import numpy as np
from flask import Flask, render_template, request
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import load_model

app = Flask(__name__)


data = pd.read_csv('emails_validity (1).csv')


label_encoder = LabelEncoder()
y = label_encoder.fit_transform(data['Type'])  # 1 for valid, 0 for invalid


emails = data['Email ID']


tokenizer = Tokenizer(char_level=True)
tokenizer.fit_on_texts(emails)


model = load_model('email_validity_model.h5')  

max_length = max([len(email) for email in emails])

def predict_email_validity(email):
    custom_sequences = tokenizer.texts_to_sequences([email])
    custom_padded = pad_sequences(custom_sequences, maxlen=max_length, padding='post')
    prediction = model.predict(custom_padded)
    return "Valid" if prediction[0][0] >= 0.5 else "Invalid"

@app.route('/', methods=['GET', 'POST'])
def index():
    result = ""
    if request.method == 'POST':
        email = request.form['email']
        result = predict_email_validity(email)
    return render_template('index.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)
